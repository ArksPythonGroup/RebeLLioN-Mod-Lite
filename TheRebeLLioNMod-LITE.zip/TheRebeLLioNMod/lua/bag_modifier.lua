-- Carry mods (throwing distance, movement speed, jumping, running)
local car_arr = { 'being', 'mega_heavy', 'heavy', 'medium', 'light', 'coke_light' }
for i, name in ipairs(car_arr) do
	tweak_data.carry.types[ name ].throw_distance_multiplier = 2.5
	tweak_data.carry.types[ name ].move_speed_modifier = 5
	tweak_data.carry.types[ name ].jump_modifier = 1.5
	tweak_data.carry.types[ name ].can_run = true
	end
	
-- No movement penalty, change to a larger value than 1 for an increase in speed
PlayerManager.body_armor_movement_penalty = function(self) return 5 end

-- Activation
active = not active
managers.hud:show_hint({text = active and "Bag Modifier Enabled"})