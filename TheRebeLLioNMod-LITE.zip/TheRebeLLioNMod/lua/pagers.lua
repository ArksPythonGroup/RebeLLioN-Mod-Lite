-- Pager to chat counter.

 
local send_to_all = true	-- Set to true if you want your whole team to read the messages
 
---------------------------------------------------------------------------------------------------------------------------------------------------
 
local pagers = 0
 
local function send_message()
	local message = pagers .. "/4 pagers answered."
	if send_to_all and managers.network:session() then
		managers.network:session():send_to_peers_ip_verified("send_chat_message", ChatManager.GAME, message) end -- Uses your name
	managers.chat:_receive_message(ChatManager.GAME,"[Pager Counter]", message, Color('fce538'))
end
 
 
local old_update = GroupAIStateBase.update
function GroupAIStateBase:update(t, dt)
	old_update(self, t, dt)
	
	if self._nr_successful_alarm_pager_bluffs ~= pagers then
		pagers = self._nr_successful_alarm_pager_bluffs
		send_message()
	end
end

-- Activation
active = not active
managers.hud:show_hint({text = active and "Pager Count to Chat Enabled"})