local amount = 1e9 -- 1e9 = 1 billion dollars, change it to whatever value you want
local currOff = managers.money:offshore()
managers.money:_set_offshore(currOff + amount)