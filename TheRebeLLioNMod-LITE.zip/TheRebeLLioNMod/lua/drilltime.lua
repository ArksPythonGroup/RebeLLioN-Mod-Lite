-- Increased Drill Time

 
local timer_multiplier = 50	-- How much faster the drilling will be: 2 = twice as fast, 0.5 = twice as long
 
------------------------------------------------------------------------------------------------------------------
 
local old_start = TimerGui._start
function TimerGui:_start(timer, current_timer)
	old_start(self, timer / timer_multiplier, current_timer)
end