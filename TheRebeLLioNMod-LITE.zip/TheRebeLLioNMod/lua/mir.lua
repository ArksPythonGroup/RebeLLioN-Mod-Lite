	for pl_key, pl_record in pairs( managers.groupai:state():all_player_criminals() ) do
		if pl_record.status ~= "dead" then
			local unit = managers.groupai:state():all_player_criminals()[ pl_key ].unit:position()
			if Network:is_client() then
				managers.network:session():send_to_host( "server_drop_carry", "meth", managers.money:get_bag_value( "meth" ), nil, nil, 0, unit, Rotation( math.UP, math.random() * 360 ), Vector3( 0,0,-100 ), 0 )
			else
				managers.player:server_drop_carry( "meth", managers.money:get_bag_value( "meth" ), nil, nil, 0, unit, Rotation( math.UP, math.random() * 360 ), Vector3( 0,0,-100 ), 0 )
			end
		end
	end

-- Message on screen
if managers.hud then
   managers.hud:show_hint( { text = "RAIN METH BAGS" } )
end