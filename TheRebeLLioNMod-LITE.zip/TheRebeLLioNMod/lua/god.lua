managers.player:player_unit():character_damage():set_invulnerable( true )

-- Activation
active = not active
managers.hud:show_hint({text = active and "God Mode Enabled"})