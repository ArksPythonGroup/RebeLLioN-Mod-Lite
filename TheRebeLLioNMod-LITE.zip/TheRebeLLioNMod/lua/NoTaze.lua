function PlayerTased:enter( state_data, enter_data )
	PlayerTased.super.enter( self, state_data, enter_data )
	self._next_shock = Application:time() + 10
	self._taser_value = 1
	self._recover_delayed_clbk = "PlayerTased_recover_delayed_clbk"
	managers.enemy:add_delayed_clbk( self._recover_delayed_clbk, callback( self, self, "clbk_exit_to_std" ), Application:time() )
end
managers.hud:show_hint( { text = "You Can No Longer Be Tazed!" } )