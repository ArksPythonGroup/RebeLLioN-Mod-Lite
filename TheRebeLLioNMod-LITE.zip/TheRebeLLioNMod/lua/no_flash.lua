-- No flashbangs
function CoreEnvironmentControllerManager:set_flashbang( flashbang_pos, line_of_sight, travel_dis, linear_dis ) end

-- Activation
active = not active
managers.hud:show_hint({text = active and "No Flashbang Effect Enabled"})