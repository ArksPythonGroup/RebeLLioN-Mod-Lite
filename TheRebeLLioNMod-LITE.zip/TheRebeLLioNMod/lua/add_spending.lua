local amount = 1e9 -- 1e9 = 1 billion dollars, change it to whatever value you want
local currSpend = managers.money:total()
managers.money:_set_total(currSpend + amount)