managers.experience:_set_current_level(100) -- level
managers.skilltree:_set_points(690) -- skill points