-- Weapon reload speed 
NewRaycastWeaponBase.reload_speed_multiplier = function(self) return 2000 end

-- Infinite ammo clip
if not _fireWep then _fireWep = NewRaycastWeaponBase.fire end
function NewRaycastWeaponBase:fire( from_pos, direction, dmg_mul, shoot_player, spread_mul, autohit_mul, suppr_mul, target_unit )
	local result = _fireWep( self, from_pos, direction, dmg_mul, shoot_player, spread_mul, autohit_mul, suppr_mul, target_unit )
	
	if managers.player:player_unit() == self._setup.user_unit then
		self.set_ammo(self, 1.0)
	end
 
	return result
end

-- Activation
active = not active
managers.hud:show_hint({text = active and "Infinite Ammo Enabled"})